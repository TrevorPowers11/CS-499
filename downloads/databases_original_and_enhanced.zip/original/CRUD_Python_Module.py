"""CRUD operations for the Austin Animal Center database."""

from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:
    """Provides CRUD access to the AAC animals collection."""

    def __init__(self, username, password):
        """Initialize the connection to MongoDB."""
        self.client = MongoClient(
            host="localhost",
            port=27017,
            username=username,
            password=password,
            authSource="admin"
        )

        self.database = self.client["aac"]
        self.collection = self.database["animals"]

    def create(self, data):
        """Insert a document and return True if successful."""
        if not isinstance(data, dict) or not data:
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as error:
            print("Create error:", error)
            return False

    def read(self, query):
        """Find matching documents and return a list."""
        if not isinstance(query, dict):
            return []

        try:
            return list(self.collection.find(query))
        except PyMongoError as error:
            print("Read error:", error)
            return []

    def update(self, query, new_data):
        """Update matching documents and return the number modified."""
        if not isinstance(query, dict) or not isinstance(new_data, dict):
            return 0

        if not query or not new_data:
            return 0

        try:
            result = self.collection.update_many(query, {"$set": new_data})
            return result.modified_count
        except PyMongoError as error:
            print("Update error:", error)
            return 0

    def delete(self, query):
        """Delete matching documents and return the number deleted."""
        if not isinstance(query, dict) or not query:
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as error:
            print("Delete error:", error)
            return 0