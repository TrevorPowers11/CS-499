"""Database-paginated dashboard. Run: python dashboard.py"""
import atexit
import base64
import math
from pathlib import Path
from dash import Dash, Input, Output, ctx, dcc, html, dash_table
import dash_leaflet as dl
import plotly.graph_objects as go
from CRUD_Python_Module import AnimalShelter, DatabaseError, FIELDS


def create_app(db):
    app = Dash(__name__)
    logo = base64.b64encode(Path(__file__).with_name('logo.png').read_bytes()).decode()
    app.layout = html.Div([
        html.Img(src='data:image/png;base64,' + logo, style={'width': '220px'}),
        html.H1('Grazioso Salvare Animal Shelter Dashboard'),
        html.P('Trevor Powers | CS 499 Database Enhancement'),
        dcc.RadioItems(id='rescue', options=[{'label': label, 'value': value} for label, value in [
            ('All animals', 'RESET'), ('Water rescue', 'WATER'),
            ('Mountain or wilderness rescue', 'MOUNTAIN'), ('Disaster or individual tracking', 'DISASTER')]], value='RESET'),
        html.Label('Exact breed search'), dcc.Input(id='breed', type='text', debounce=True),
        html.Div(id='status', role='status'),
        dash_table.DataTable(id='animals', columns=[{'name': f.replace('_', ' ').title(), 'id': f} for f in sorted(FIELDS)],
            data=[], page_action='custom', page_current=0, page_size=10, page_count=0,
            sort_action='custom', sort_mode='single', sort_by=[], row_selectable='single', selected_rows=[],
            style_table={'overflowX': 'auto'}, style_cell={'textAlign': 'left'}),
        dcc.Graph(id='summary'), html.Div(id='map')
    ], style={'maxWidth': '1200px', 'margin': '24px auto'})

    @app.callback(Output('animals', 'data'), Output('animals', 'page_count'),
                  Output('animals', 'page_current'), Output('animals', 'selected_rows'),
                  Output('summary', 'figure'), Output('status', 'children'),
                  Input('rescue', 'value'), Input('breed', 'value'),
                  Input('animals', 'page_current'), Input('animals', 'sort_by'))
    def refresh(rescue, breed, page, sorting):
        if ctx.triggered_id in {'rescue', 'breed'}:
            page = 0
        filters = {'breed': breed.strip()} if breed and breed.strip() else {}
        order = sorting[0] if sorting else {'column_id': 'animal_id', 'direction': 'asc'}
        try:
            result = db.read_page(rescue, filters, page=page or 0, sort_field=order['column_id'],
                                  direction=-1 if order['direction'] == 'desc' else 1)
            summary = db.summary(rescue, filters)
            figure = go.Figure(go.Bar(x=[x.get('category') or 'Unknown' for x in summary],
                                     y=[x['count'] for x in summary]))
            figure.update_layout(title='Top 10 breeds across all matching records')
            return result['records'], result['page_count'], result['page'], [], figure, f"{result['total']} matching records"
        except (ValueError, DatabaseError) as error:
            return [], 0, 0, [], go.Figure(), str(error)

    @app.callback(Output('map', 'children'), Input('animals', 'data'), Input('animals', 'selected_rows'))
    def update_map(records, selected):
        if not records:
            return html.P('No map data available.')
        index = selected[0] if selected and 0 <= selected[0] < len(records) else 0
        record = records[index]
        lat, lon = record.get('location_lat'), record.get('location_long')
        if not all(isinstance(x, (int, float)) and math.isfinite(x) for x in (lat, lon)) or not (-90 <= lat <= 90 and -180 <= lon <= 180):
            return html.P('Selected animal has no valid location.')
        return dl.Map([dl.TileLayer(), dl.Marker(position=[lat, lon], children=[
            dl.Tooltip(str(record.get('breed', 'Unknown'))),
            dl.Popup(str(record.get('name', 'Unnamed animal')))])],
            center=[lat, lon], zoom=10, style={'height': '400px'})
    return app


if __name__ == '__main__':
    db = AnimalShelter()
    atexit.register(db.close)
    create_app(db).run(debug=False)
