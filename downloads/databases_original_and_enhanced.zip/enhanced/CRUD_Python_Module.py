"""Controlled MongoDB access for the CS 499 database enhancement."""
import logging
import math
import os
from pymongo import MongoClient, ASCENDING
from pymongo.errors import PyMongoError

LOG = logging.getLogger(__name__)
FIELDS = {'animal_id', 'animal_type', 'breed', 'name', 'sex_upon_outcome',
          'age_upon_outcome_in_weeks', 'location_lat', 'location_long', 'outcome_type'}
SORT_FIELDS = {'animal_id', 'name', 'breed', 'age_upon_outcome_in_weeks'}
RULES = {
    'WATER': (['Labrador Retriever Mix', 'Chesapeake Bay Retriever', 'Newfoundland'], 'Intact Female', 26, 156),
    'MOUNTAIN': (['German Shepherd', 'Alaskan Malamute', 'Old English Sheepdog', 'Siberian Husky', 'Rottweiler'], 'Intact Male', 26, 156),
    'DISASTER': (['Doberman Pinscher', 'German Shepherd', 'Golden Retriever', 'Bloodhound', 'Rottweiler'], 'Intact Male', 20, 300),
}

class DatabaseError(RuntimeError):
    """Safe error for the application; driver details never reach the UI."""


def controlled_query(rescue='RESET', filters=None):
    if rescue not in {'RESET', *RULES}:
        raise ValueError('Unknown rescue category.')
    if filters is None:
        filters = {}
    if not isinstance(filters, dict) or set(filters) - FIELDS:
        raise ValueError('Unsupported filter field.')
    for field, value in filters.items():
        validate_value(field, value)
    query = dict(filters)
    if rescue != 'RESET':
        breeds, sex, low, high = RULES[rescue]
        rule = {'animal_type': 'Dog', 'breed': {'$in': breeds},
                'sex_upon_outcome': sex,
                'age_upon_outcome_in_weeks': {'$gte': low, '$lte': high}}
        query = {'$and': [rule, query]} if query else rule
    return query


def validate_value(field, value):
    if field in {'age_upon_outcome_in_weeks', 'location_lat', 'location_long'}:
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError('Numeric values must be finite numbers.')
        if field == 'age_upon_outcome_in_weeks' and value < 0:
            raise ValueError('Age cannot be negative.')
        if field == 'location_lat' and not -90 <= value <= 90:
            raise ValueError('Invalid latitude.')
        if field == 'location_long' and not -180 <= value <= 180:
            raise ValueError('Invalid longitude.')
    elif not isinstance(value, str) or not value.strip() or len(value) > 200:
        raise ValueError('Text values must contain 1 to 200 characters.')


def guard(operation):
    """Translate driver failures without leaking credentials or server details."""
    def wrapped(*args, **kwargs):
        try:
            return operation(*args, **kwargs)
        except PyMongoError as error:
            LOG.error('Database operation %s failed (%s)', operation.__name__, type(error).__name__)
            raise DatabaseError('Database operation failed. Check configuration and try again.') from None
    return wrapped


class AnimalShelter:
    def __init__(self, *, collection=None):
        self.client = None
        if collection is not None:  # Dependency injection for isolated tests.
            self.collection = collection
            return
        uri = os.environ.get('MONGODB_URI')
        if not uri:
            raise ValueError('Set MONGODB_URI before starting the application.')
        try:
            self.client = MongoClient(uri, serverSelectionTimeoutMS=5000, connectTimeoutMS=5000)
            self.client.admin.command('ping')
            self.collection = self.client[os.getenv('MONGODB_DATABASE', 'aac')][os.getenv('MONGODB_COLLECTION', 'animals')]
        except PyMongoError as error:
            if self.client is not None:
                self.client.close()
            LOG.error('Database connection failed (%s)', type(error).__name__)
            raise DatabaseError('Unable to connect to the database. Check configuration.') from None

    @guard
    def ensure_indexes(self):
        return [self.collection.create_index([
                    ('animal_type', ASCENDING), ('sex_upon_outcome', ASCENDING),
                    ('breed', ASCENDING), ('age_upon_outcome_in_weeks', ASCENDING)], name='rescue_filter'),
                self.collection.create_index('animal_id', name='animal_id_lookup')]

    @guard
    def read_page(self, rescue='RESET', filters=None, *, page=0, page_size=10, sort_field='animal_id', direction=1):
        if type(page) is not int or page < 0 or page > 100000:
            raise ValueError('Page must be an integer from 0 to 100000.')
        if type(page_size) is not int or not 1 <= page_size <= 100:
            raise ValueError('Page size must be from 1 to 100.')
        if sort_field not in SORT_FIELDS or type(direction) is not int or direction not in (-1, 1):
            raise ValueError('Unsupported sort request.')
        query = controlled_query(rescue, filters)
        total = self.collection.count_documents(query)
        effective_page = min(page, max(0, (total - 1) // page_size))
        # _id is the tie-breaker even if animal_id is duplicated in outcome records.
        cursor = self.collection.find(query, {'_id': 0, **{f: 1 for f in FIELDS}}).sort(
            [(sort_field, direction), ('_id', direction)]).skip(effective_page * page_size).limit(page_size)
        return {'records': list(cursor), 'total': total, 'page': effective_page,
                'page_count': (total + page_size - 1) // page_size}

    @guard
    def summary(self, rescue='RESET', filters=None, *, group_by='breed'):
        if group_by not in {'breed', 'animal_type', 'outcome_type'}:
            raise ValueError('Unsupported summary field.')
        pipeline = [{'$match': controlled_query(rescue, filters)},
                    {'$group': {'_id': '$' + group_by, 'count': {'$sum': 1}}},
                    {'$sort': {'count': -1, '_id': 1}}, {'$limit': 10},
                    {'$project': {'_id': 0, 'category': '$_id', 'count': 1}}]
        return list(self.collection.aggregate(pipeline))

    def _document(self, data, *, creating=False):
        if not isinstance(data, dict) or not data or set(data) - FIELDS:
            raise ValueError('Use supported animal fields only.')
        if creating and not {'animal_id', 'animal_type', 'breed'} <= set(data):
            raise ValueError('Animal ID, type and breed are required.')
        for field, value in data.items():
            validate_value(field, value)
        return dict(data)

    @guard
    def create(self, data):
        return self.collection.insert_one(self._document(data, creating=True)).acknowledged

    def _write_query(self, filters):
        query = controlled_query(filters=filters)
        if not query or 'animal_id' not in query:
            raise ValueError('Writes require an animal_id filter.')
        return query

    @guard
    def update(self, filters, new_data):
        query = self._write_query(filters)
        data = self._document(new_data)
        if 'animal_id' in data:
            raise ValueError('Animal ID cannot be changed.')
        return self.collection.update_many(query, {'$set': data}).modified_count

    @guard
    def delete(self, filters):
        return self.collection.delete_many(self._write_query(filters)).deleted_count

    def close(self):
        if self.client is not None:
            self.client.close()
