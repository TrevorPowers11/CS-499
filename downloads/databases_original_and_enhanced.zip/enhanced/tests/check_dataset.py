"""Offline integration check against the supplied AAC CSV; not a speed benchmark."""
import csv
import sys
from collections import Counter
from pathlib import Path
import mongomock
from CRUD_Python_Module import AnimalShelter, RULES

path=Path(sys.argv[1])
with path.open(newline='') as stream:
    records=list(csv.DictReader(stream))
for record in records:
    for field in ('location_lat','location_long','age_upon_outcome_in_weeks'):
        record[field]=float(record[field]) if record[field] else None
collection=mongomock.MongoClient().aac.animals
collection.insert_many(records)
db=AnimalShelter(collection=collection)
for rescue in ('RESET',*RULES):
    expected=records
    if rescue!='RESET':
        breeds,sex,low,high=RULES[rescue]
        expected=[r for r in records if r['animal_type']=='Dog' and r['breed'] in breeds
                  and r['sex_upon_outcome']==sex and r['age_upon_outcome_in_weeks'] is not None
                  and low <= r['age_upon_outcome_in_weeks'] <= high]
    page=db.read_page(rescue)
    assert page['total']==len(expected)
    counts=Counter(r['breed'] for r in expected)
    summary=db.summary(rescue)
    assert [(r['category'],r['count']) for r in summary]==sorted(counts.items(),key=lambda x:(-x[1],x[0]))[:10]
    print(f'{rescue}: {len(expected)} matches; page and full-result summary verified')
