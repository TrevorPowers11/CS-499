import unittest
from unittest.mock import patch
import mongomock
from pymongo.errors import OperationFailure
from CRUD_Python_Module import AnimalShelter, DatabaseError, controlled_query
from dashboard import create_app

class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.collection = mongomock.MongoClient().aac.animals
        self.db = AnimalShelter(collection=self.collection)
        self.collection.insert_many([{'animal_id': f'A{i:03}', 'animal_type': 'Dog',
            'breed': 'Labrador Retriever Mix', 'sex_upon_outcome': 'Intact Female',
            'age_upon_outcome_in_weeks': 26+i, 'name': f'Animal {i}',
            'location_lat': 30.2, 'location_long': -97.7} for i in range(25)])

    def test_disjoint_pages_and_projection(self):
        a = self.db.read_page()['records']; b = self.db.read_page(page=1)['records']
        self.assertEqual(len(a), 10)
        self.assertFalse({x['animal_id'] for x in a} & {x['animal_id'] for x in b})
        self.assertNotIn('_id', a[0])
        self.assertEqual(self.db.read_page(page=2)['total'], 25)
        self.assertEqual(len(self.db.read_page(page=999)['records']), 5)

    def test_rescue_boundaries_and_intersection(self):
        self.collection.insert_one({'animal_id':'OUT','animal_type':'Dog','breed':'Labrador Retriever Mix',
            'sex_upon_outcome':'Intact Female','age_upon_outcome_in_weeks':157})
        self.assertEqual(self.db.read_page('WATER')['total'],25)
        self.assertEqual(self.db.read_page('WATER', {'breed':'Bloodhound'})['total'],0)
        self.assertEqual(self.db.read_page('MOUNTAIN')['total'],0)
        self.assertIn('$gte',controlled_query('DISASTER')['age_upon_outcome_in_weeks'])

    def test_summary_covers_all_pages(self):
        self.assertEqual(self.db.summary()[0]['count'],25)

    def test_injection_and_invalid_inputs(self):
        for filters in [{'breed':{'$ne':None}}, {'$where':'malicious'}, {'age_upon_outcome_in_weeks':float('nan')}]:
            with self.assertRaises(ValueError): self.db.read_page(filters=filters)
        for args in [{'page_size':0},{'page':-1},{'sort_field':'$where'},{'direction':True}]:
            with self.assertRaises(ValueError): self.db.read_page(**args)
        with self.assertRaises(ValueError): self.db.summary(group_by='$where')

    def test_crud_and_write_guards(self):
        self.assertTrue(self.db.create({'animal_id':'NEW','animal_type':'Cat','breed':'Domestic Shorthair'}))
        self.assertEqual(self.db.update({'animal_id':'NEW'},{'name':'Milo'}),1)
        self.assertEqual(self.db.delete({'animal_id':'NEW'}),1)
        with self.assertRaises(ValueError): self.db.delete({})
        with self.assertRaises(ValueError): self.db.update({'breed':'Dog'},{'name':'Bad'})
        with self.assertRaises(ValueError): self.db.create({'animal_id':'bad'})

    def test_indexes_are_idempotent(self):
        self.db.ensure_indexes(); self.db.ensure_indexes()
        self.assertIn('rescue_filter',self.collection.index_information())

    def test_safe_error_and_empty_distinction(self):
        self.assertEqual(self.db.read_page(filters={'animal_id':'missing'})['total'],0)
        with patch.object(self.collection,'count_documents',side_effect=OperationFailure('secret-uri')):
            with self.assertRaises(DatabaseError) as caught: self.db.read_page()
        self.assertNotIn('secret-uri',str(caught.exception))

    def test_dashboard_layout_served(self):
        client=create_app(self.db).server.test_client()
        self.assertEqual(client.get('/').status_code,200)
        self.assertEqual(client.get('/_dash-layout').status_code,200)

if __name__ == '__main__': unittest.main()
