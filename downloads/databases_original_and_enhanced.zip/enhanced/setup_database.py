"""Run once with a database account authorized to create indexes."""
from CRUD_Python_Module import AnimalShelter
if __name__ == '__main__':
    db = AnimalShelter()
    try:
        print('Indexes ensured:', db.ensure_indexes())
    finally:
        db.close()
