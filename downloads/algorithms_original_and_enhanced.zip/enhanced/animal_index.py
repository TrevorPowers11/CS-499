"""In-memory search, filtering and sorting for shelter dashboard records."""

from collections import defaultdict

RESCUE = {
    "WATER": ({"Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"}, "Intact Female", 26, 156),
    "MOUNTAIN": ({"German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"}, "Intact Male", 26, 156),
    "DISASTER": ({"Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"}, "Intact Male", 20, 300),
}
SORT_FIELDS = {"animal_id", "name", "breed", "age_upon_outcome_in_weeks"}


class AnimalIndex:
    """Build hash buckets once; use them for repeated exact-match queries."""

    def __init__(self, records):
        self.records = [{k: v for k, v in row.items() if k != "_id"} for row in records]
        self.by_breed = defaultdict(list)
        self.by_id = defaultdict(list)
        for position, row in enumerate(self.records):
            self.by_breed[row.get("breed")].append(position)
            self.by_id[row.get("animal_id")].append(position)

    def search(self, rescue="RESET", animal_id="", breed="", sort_by="animal_id", descending=False):
        """Intersect indexed candidates, then apply the remaining conditions."""
        if rescue not in (*RESCUE, "RESET"):
            raise ValueError("Unknown rescue type")
        if sort_by not in SORT_FIELDS:
            raise ValueError("Unsupported sort field")
        buckets = []
        if animal_id and animal_id.strip():
            buckets.append(set(self.by_id.get(animal_id.strip(), ())))
        if breed and breed.strip():
            buckets.append(set(self.by_breed.get(breed.strip(), ())))
        if rescue != "RESET":
            breeds, sex, minimum, maximum = RESCUE[rescue]
            buckets.append(set().union(*(self.by_breed.get(b, ()) for b in breeds)))
        candidates = sorted(set.intersection(*buckets)) if buckets else range(len(self.records))
        results = []
        for position in candidates:
            row = self.records[position]
            if rescue != "RESET":
                if row.get("animal_type") != "Dog" or row.get("sex_upon_outcome") != sex:
                    continue
                age = row.get("age_upon_outcome_in_weeks")
                if not isinstance(age, (int, float)) or not minimum <= age <= maximum:
                    continue
            results.append(row)
        # Missing values stay last in either direction; Python's sort is stable.
        present = [r for r in results if r.get(sort_by) is not None]
        missing = [r for r in results if r.get(sort_by) is None]
        present.sort(key=lambda r: str(r[sort_by]).casefold() if sort_by != "age_upon_outcome_in_weeks" else float(r[sort_by]), reverse=descending)
        return present + missing
